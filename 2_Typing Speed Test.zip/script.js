
const targetText = document.getElementById('targetText').textContent;
const inputField = document.getElementById('inputField');
const result = document.getElementById('result');
const restartButton = document.getElementById('restartButton');

let startTime;
let finished = false;

inputField.addEventListener('input', () => {
    if (!startTime) {
        startTime = new Date();
    }
    
    if (!finished && inputField.value === targetText) {
        const endTime = new Date();
        const timeTaken = ((endTime - startTime) / 1000).toFixed(2);
        result.textContent = `Well done! You completed the test in ${timeTaken} seconds.`;
        finished = true;
    }
});

restartButton.addEventListener('click', () => {
    inputField.value = '';
    result.textContent = '';
    startTime = null;
    finished = false;
});
